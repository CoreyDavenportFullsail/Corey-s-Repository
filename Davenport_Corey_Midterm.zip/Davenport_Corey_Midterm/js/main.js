/*
	* Mid Terms for PWA-1 1304
	* Corey Davenport 02/15/2014
*/
(function(){
    //logging "Connected" to insure that main.js is properly attached to .html file
    console.log(".js to .html is connected");

    console.log("***** This is an array of students before another student is added *****");
    var studentNumber = 0;
    var studentInfo = [
       //First student info stored below
        {name:"Hal Jordan",
         address:{street:"22 Sea View",
                  city:"Coast City",
                  state:"California"},
         GPA:[2.75,3.0,4.0],
         average: average([2.75,3.0,4.0])   },

       //Second student info stored below
        {name:"Guy Gardner",
         address:{street:"666 Random Street",
                city:"Baltimore",
                state:"Maryland"},
         GPA:[2.0,1.5,1.0],
            average: average([2.0,1.5,1.0])}
        ];
    console.log(infoPrint());
    
        //Below is a function that will print the student info to the console
    function infoPrint(){
        for (var i = 0; i < studentInfo.length; i++){
            console.log("Name : "+studentInfo[i].name + "\n",
                                     "Street : "+studentInfo[i].address.street + "\n",
                                     "City : "+studentInfo[i].address.city + "\n",
                                     "State : "+studentInfo[i].address.state + "\n",
                                     "GPA : "+studentInfo[i].GPA + "\n",
                                     "Average : "+studentInfo[i].average );

        }

    console.log("***** This is the array of students after an additional student is added *****");
        //Below is a function that will push an additional object into the studentInfo array
        addStudent("Kyle Rayner",{street:"999 Random Location",city:"Coast City",state:"California"},[3.0,2.5,4.0],average([3.0,2.5,4.0]));
        function addStudent(name,address,GPA,Avg){
            var newStudent = {"name": name,
                               "address": address,
                                "GPA": GPA,
                                "Average": Avg};
            studentInfo.push(newStudent);

        }

        //Below will print out the full list of student info, with new student added

    }
    console.log(infoPrintAgain());
    function infoPrintAgain(){
        for (var j = 0; j < studentInfo.length; j++){
            console.log("Name : "+studentInfo[j].name + "\n",
                "Street : "+studentInfo[j].address.street + "\n",
                "City : "+studentInfo[j].address.city + "\n",
                "State : "+studentInfo[j].address.state + "\n",
                "GPA : "+studentInfo[j].GPA + "\n",
                "Average : "+studentInfo[j].average);
        }
    }

    var buttonClick = document.querySelector(".buttonred");
    buttonClick.addEventListener("click", onClick);















function average(gpa){
    var addedNum = 0;
    for (var i = 0; i < gpa.length; i++){
        addedNum += gpa[i];
    }
    var total = addedNum/gpa.length;
    return total;

}














    if (studentNumber == 0) {
        var name1 = document.querySelector("#name");
        var address = document.querySelector("#address");
        var GPA = document.querySelector("#gpa");
        var date = document.querySelector("#date");
        var average = document.querySelector("#gpaavg");

        name1.innerHTML = "name: " + studentInfo[0].name;
        address.innerHTML = "address: " + studentInfo[0].address.street + " " + studentInfo[0].address.city + " " + studentInfo[0].address.State;
        GPA.innerHTML = "GPA: " + studentInfo[0].GPA;
        average.innerHTML = "average: " + studentInfo[0].average;
    }
    function onClick(e) {

        studentNumber++;


        if (studentNumber == 1) {
            name1.innerHTML = "name: " + studentInfo[1].name;
            address.innerHTML = "address: " + studentInfo[1].address.street + " " + studentInfo[1].address.city + " " + studentInfo[1].address.State;
            GPA.innerHTML = "GPA: " + studentInfo[1].GPA;
            average.innerHTML = "average: " + studentInfo[1].average;
        } else if (studentNumber == 2) {
            name1.innerHTML = "name: " + studentInfo[2].name;
            address.innerHTML = "address: " + studentInfo[2].address.street + " " + studentInfo[2].address.city + " " + studentInfo[2].address.State;
            GPA.innerHTML = "GPA: " + studentInfo[2].GPA;
            average.innerHTML = "average: " + studentInfo[2].average;
            buttonClick.innerHTML = "Done!";
            buttonClick.removeEventListener("click", onClick);

        }


    }







})();